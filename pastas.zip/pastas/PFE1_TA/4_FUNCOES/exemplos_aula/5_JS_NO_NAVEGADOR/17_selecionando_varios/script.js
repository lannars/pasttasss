let itens = document.querySelectorAll('.itens-verdes');
console.log(itens[0].style.color);

itens[0].style.color = 'red';
console.log(itens[0].style.color);

let itens2 = document.querySelector('.itens-azuis');
console.log(itens2);