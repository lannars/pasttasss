let novoElemento = document.createElement('p');
let texto = document.createTextNode('palmeiras')

novoElemento.appendChild(texto);

let elementAlvo = document.querySelector('#titulo-principal')
let elementoPai = document.querySelector('#container-principal');

elementoPai.insertBefore(novoElemento,elementAlvo);