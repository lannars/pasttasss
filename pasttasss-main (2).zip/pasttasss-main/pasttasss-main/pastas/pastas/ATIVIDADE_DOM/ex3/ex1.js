// criew uma função que calcule a soma de 2 numeros passados via inputao 
// ao clicar no botão o mesmo deve retornar o resultado!

function calcule() {
    let num1 = Number(document.getElementById('n1').value);
    let num2 = Number(document.getElementById('n2').value);

    var soma = num1 + num2;

    const resultado = document.getElementById('resultado');
    resultado.textContent = 'Resultado = ' + soma;
}