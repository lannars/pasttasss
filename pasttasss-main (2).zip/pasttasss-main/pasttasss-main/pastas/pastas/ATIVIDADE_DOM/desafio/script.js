function alterarTamanho(){
document.body.style.width = 200;
document.body.style.height = 200;
}

const botao = document.getElementById("square");
botao.addEventListener("click", alterarTamanho);

