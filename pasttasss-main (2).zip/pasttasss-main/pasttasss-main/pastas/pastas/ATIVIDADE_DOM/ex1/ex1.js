//ex1 - criar uma função para alterar o conteúdo de um parágrafo e 
//criar um botão para isso

function alterarParagrafo(){
    const parágrafo = document.getElementById("paragrafo");
    parágrafo.textContent = "tira o casaco";
}

const botao = document.getElementById("meuBotao");
botao.addEventListener("click", alterarParagrafo);