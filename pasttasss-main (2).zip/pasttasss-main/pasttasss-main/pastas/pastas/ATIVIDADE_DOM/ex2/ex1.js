// * Crie uma hierarquia da sua família utilizando os conceitos de DOM
function destacarElemento(){
    let Biso = document.getElementById("Mamae");
    Biso.style.color = "red";
}