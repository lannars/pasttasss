function alterarCorFundo(){
document.body.style.backgroundColor = "blue";
}

const botao = document.getElementById("meuBotao");
botao.addEventListener("click", alterarCorFundo);