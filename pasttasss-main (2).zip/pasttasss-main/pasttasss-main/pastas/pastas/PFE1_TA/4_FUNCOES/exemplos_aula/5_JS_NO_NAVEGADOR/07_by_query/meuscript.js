console.log(document.querySelector('#container principal h1'));
console.log(document.querySelector('#segundo principal h1'));
console.log(document.querySelector('div div p'));
console.log(document.querySelector('ul .ITENS AZUIS'));