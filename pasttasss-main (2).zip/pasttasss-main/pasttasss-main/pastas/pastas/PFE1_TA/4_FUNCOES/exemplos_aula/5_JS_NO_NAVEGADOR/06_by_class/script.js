console.log(document.getElementsByTagName('li'));
console.log(document.getElementsByClassName('ITENS AZUIS'));
console.log(document.getElementsByClassName('ITENS VERDES'));
console.log(document.getElementsByClassName('itens'));